This folder contains source code from the library SharpZipLib
http://www.icsharpcode.net/opensource/sharpziplib/
It is a subset of that library, with minor modifications.
to provide support for CSC32 and Inflater/Deflater 
streams (the official DeflaterStream is a joke).
The library is originally released under the GPL,
and so is this PNGCS project.